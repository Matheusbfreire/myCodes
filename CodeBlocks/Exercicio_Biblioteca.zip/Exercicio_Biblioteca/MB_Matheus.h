#ifndef MB_MATHEUS_H_INCLUDED
#define MB_MATHEUS_H_INCLUDED
int multiplicacao (int , int );
int soma_intervalo(int , int );
int impares_intervalo(int , int );
#endif // MB_MATHEUS_H_INCLUDED
