package app;

public class PessoaFisica extends Pessoa {
	private String cpf;
	
	private void initFisica(String cpf) {
		this.cpf = cpf;
	}
	
	public PessoaFisica() {
		super();
		initFisica("11122233344");
	}
	
	public PessoaFisica(String nome, String endereco, String telefone, String cep, String cidade, String uf, String cpf) {
		super(nome, endereco, telefone, cep, cidade, uf);
		initFisica(cpf);
	}
	
	public String getCodigoDePessoa() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
}
