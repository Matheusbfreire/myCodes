package app;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PessoaFisicaTest {
	
	PessoaFisica pessoa1;
	PessoaFisica pessoa2;

	@BeforeEach
	void setUp() throws Exception {
		pessoa1 = new PessoaFisica();
		pessoa2 = new PessoaFisica("Matheus", "Rua frutal, 320, Santa Efigenia", "31973072137", "30260150", "Belo Horizonte", "MG", "15804814699");
	}

	@Test
	void testeDeCria��oDosAtributos() {
		assertEquals("Fulano", pessoa1.getNome());
		assertEquals("Rua rua, 110, Santa Tereza", pessoa1.getEndereco());
		assertEquals("31999991111", pessoa1.getTelefone());
		assertEquals("30270140", pessoa1.getCep());
		assertEquals("Belo Horizonte", pessoa1.getCidade());
		assertEquals("MG", pessoa1.getUf());
		assertEquals("11122233344", pessoa1.getCodigoDePessoa());
		
		assertEquals("Matheus", pessoa2.getNome());
		assertEquals("Rua frutal, 320, Santa Efigenia", pessoa2.getEndereco());
		assertEquals("31973072137", pessoa2.getTelefone());
		assertEquals("30260150", pessoa2.getCep());
		assertEquals("Belo Horizonte", pessoa2.getCidade());
		assertEquals("MG", pessoa2.getUf());
		assertEquals("15804814699", pessoa2.getCodigoDePessoa());
	}

}
