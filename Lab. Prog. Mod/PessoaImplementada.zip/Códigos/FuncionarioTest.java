package app;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FuncionarioTest {
	
	Funcionario funcionario1;
	Funcionario funcionario2;
	PessoaFisica pessoa;

	@BeforeEach
	void setUp() throws Exception {
		pessoa = new PessoaFisica();
		funcionario1 = new Funcionario();
		funcionario2 = new Funcionario("administrador", 1500, pessoa);
	}

	@Test
	void testeDeCria��oDosAtributos() {
		assertEquals("Fulano", funcionario1.getPessoa().getNome());
		assertEquals("Rua rua, 110, Santa Tereza", funcionario1.getPessoa().getEndereco());
		assertEquals("31999991111", funcionario1.getPessoa().getTelefone());
		assertEquals("30270140", funcionario1.getPessoa().getCep());
		assertEquals("Belo Horizonte", funcionario1.getPessoa().getCidade());
		assertEquals("MG", funcionario1.getPessoa().getUf());
		assertEquals("11122233344", funcionario1.getPessoa().getCodigoDePessoa());
		assertEquals("indefinido", funcionario1.getCargo());
		assertEquals(0, funcionario1.getSalario());
		
		assertEquals("Fulano", funcionario2.getPessoa().getNome());
		assertEquals("Rua rua, 110, Santa Tereza", funcionario2.getPessoa().getEndereco());
		assertEquals("31999991111", funcionario2.getPessoa().getTelefone());
		assertEquals("30270140", funcionario2.getPessoa().getCep());
		assertEquals("Belo Horizonte", funcionario2.getPessoa().getCidade());
		assertEquals("MG", funcionario2.getPessoa().getUf());
		assertEquals("11122233344", funcionario2.getPessoa().getCodigoDePessoa());
		assertEquals("administrador", funcionario2.getCargo());
		assertEquals(1500, funcionario2.getSalario());
	}

}
