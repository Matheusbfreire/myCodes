package app;

import java.util.LinkedList;

public class Empresa {
	private LinkedList<Cliente> listaClientes = new LinkedList<>();
	private LinkedList<Funcionario> listaFuncionarios = new LinkedList<>();
	private Funcionario presidente;
	
	public void adicionaCliente(Cliente cliente) {
		this.listaClientes.add(cliente);
	}
	
	public void adicionaFuncionario(Funcionario funcionario) {
		this.listaFuncionarios.add(funcionario);
	}
	
	public void definePresidente(Funcionario funcionario) {
		if (funcionario.getCargo().compareTo("presidente") == 0) {
			this.presidente = funcionario;
			this.adicionaFuncionario(presidente);
		}
	}

	public LinkedList<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(LinkedList<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}

	public LinkedList<Funcionario> getListaFuncionarios() {
		return listaFuncionarios;
	}

	public void setListaFuncionarios(LinkedList<Funcionario> listaFuncionarios) {
		this.listaFuncionarios = listaFuncionarios;
	}

	public Funcionario getPresidente() {
		return presidente;
	}

	public void setPresidente(Funcionario presidente) {
		this.presidente = presidente;
	}
	
}
