package app;

public class Funcionario {
	private String cargo;
	private double salario;
	private PessoaFisica pessoa;
	
	private void init(String cargo, double salario, PessoaFisica pessoa) {
		this.cargo = cargo;
		this.salario = salario;
		this.pessoa = pessoa;
	}
	
	public Funcionario() {
		this.init("indefinido", 0, new PessoaFisica());
	}
	
	public Funcionario(String cargo, double salario, PessoaFisica pessoa) {
		this.init(cargo, salario, pessoa);
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public PessoaFisica getPessoa() {
		return pessoa;
	}

	public void setPessoa(PessoaFisica pessoa) {
		this.pessoa = pessoa;
	}
}
