package app;

public class PessoaJuridica extends Pessoa {
	private String cnpj;
	
	private void initJuridica(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public PessoaJuridica() {
		super();
		initJuridica("16816712388");
	}
	
	public PessoaJuridica(String nome, String endereco, String telefone, String cep, String cidade, String uf, String cnpj) {
		super(nome, endereco, telefone, cep, cidade, uf);
		initJuridica(cnpj);
	}
	
	public String getCodigoDePessoa() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
}
