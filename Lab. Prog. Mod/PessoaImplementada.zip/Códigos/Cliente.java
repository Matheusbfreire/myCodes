package app;

public class Cliente {
	private double limiteCredito;
	private Pessoa pessoa;
	
	private void init(Pessoa pessoa, double limiteCredito) {
		this.pessoa = pessoa;
		this.limiteCredito = limiteCredito; 
	}
	
	public Cliente(Pessoa pessoa) {
		this.init(pessoa, 0);
	}
	
	public Cliente(Pessoa pessoa, double limiteCredito) {
		this.init(pessoa, limiteCredito);
	}

	public double getLimiteCredito() {
		return limiteCredito;
	}

	public void setLimiteCredito(double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	
}
