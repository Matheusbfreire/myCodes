package app;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EmpresaTest {

	Empresa empresa;
	PessoaFisica pessoa;
	Cliente cliente;
	Funcionario funcionario;
	
	@BeforeEach
	void setUp() throws Exception {
		empresa = new Empresa();
		cliente = new Cliente(pessoa);
		funcionario = new Funcionario();
	}

	@Test
	void testeDeAdicaoDeClientesEFuncionariosNasListas() {
		empresa.adicionaCliente(cliente);
		empresa.adicionaFuncionario(funcionario);
		empresa.adicionaFuncionario(funcionario);
		
		assertEquals(1, empresa.getListaClientes().size());
		assertEquals(2, empresa.getListaFuncionarios().size());
	}
	
	@Test
	void testeDeCriacaoDePresidente() {
		empresa.adicionaFuncionario(funcionario);
		empresa.definePresidente(funcionario);
		
		assertEquals(1, empresa.getListaFuncionarios().size());
		
		funcionario = new Funcionario("presidente", 5000, pessoa);
		empresa.definePresidente(funcionario);
		
		assertEquals(2, empresa.getListaFuncionarios().size());
	}

}
