package app;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ClienteTest {

	Cliente cliente1;
	Cliente cliente2;
	PessoaFisica fisica;
	PessoaJuridica juridica;
	
	@BeforeEach
	void setUp() throws Exception {
		fisica = new PessoaFisica();
		juridica = new PessoaJuridica();
		cliente1 = new Cliente(fisica);
		cliente2 = new Cliente(juridica, 1000);
	}

	@Test
	void testeDeCria��oDosAtributosClienteFisico() {
		assertEquals("Fulano", cliente1.getPessoa().getNome());
		assertEquals("Rua rua, 110, Santa Tereza", cliente1.getPessoa().getEndereco());
		assertEquals("31999991111", cliente1.getPessoa().getTelefone());
		assertEquals("30270140", cliente1.getPessoa().getCep());
		assertEquals("Belo Horizonte", cliente1.getPessoa().getCidade());
		assertEquals("MG", cliente1.getPessoa().getUf());
		assertEquals("11122233344", cliente1.getPessoa().getCodigoDePessoa());
		assertEquals(0, cliente1.getLimiteCredito());
	}
	
	void testeDeCria��oDosAtributosClienteJuridico() {
		assertEquals("Fulano", cliente2.getPessoa().getNome());
		assertEquals("Rua rua, 110, Santa Tereza", cliente2.getPessoa().getEndereco());
		assertEquals("31999991111", cliente2.getPessoa().getTelefone());
		assertEquals("30270140", cliente2.getPessoa().getCep());
		assertEquals("Belo Horizonte", cliente2.getPessoa().getCidade());
		assertEquals("MG", cliente2.getPessoa().getUf());
		assertEquals("16816712388", cliente2.getPessoa().getCodigoDePessoa());
		assertEquals(1000, cliente2.getLimiteCredito());
	}

}
