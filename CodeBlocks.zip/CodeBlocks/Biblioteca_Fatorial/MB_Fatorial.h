#ifndef MB_FATORIAL_H_INCLUDED
#define MB_FATORIAL_H_INCLUDED
int fatorial(int );
#endif // MB_FATORIAL_H_INCLUDED
