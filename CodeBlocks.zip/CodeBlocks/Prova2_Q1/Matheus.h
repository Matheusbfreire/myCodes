#ifndef MATHEUS_H_INCLUDED
#define MATHEUS_H_INCLUDED
float valorDeH(int );
#endif // MATHEUS_H_INCLUDED
