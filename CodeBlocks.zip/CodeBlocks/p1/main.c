#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Ol�, Mundo!");
    return 0;
}
