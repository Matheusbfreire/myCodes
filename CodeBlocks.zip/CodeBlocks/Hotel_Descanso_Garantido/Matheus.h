#ifndef MATHEUS_H_INCLUDED
#define MATHEUS_H_INCLUDED
void escolha();
void infoQuartos(int );
void criarArquivo();
void infoGeral();
void modificaStatus();
#endif // MATHEUS_H_INCLUDED
